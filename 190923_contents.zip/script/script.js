$(document).ready(function(){
    var count = 0;
    $("#write").click(function(){
        count++;
        var old = $("#content").html();
        $("#content").html(old + "<b>ㅋ</b>" + count + " ");
    });
//1. #write 버튼이 눌리면
//2. 기존에 #content에 뭐라고 써놨었는지 알아내 둔다.
//    (그렇지 않으면 기존에 써놨던 내용들은 다 사라지게 되므로)
//3. 기존에 써놨던 내용의 오른쪽에 새 내용(ㅋㅋㅋ)을 추가하고
//4. #content에 최종 내용을 삽입한다.
    
    $("#read").click(function(){
        var ctext = $("#content").text();
        alert(ctext);
    });
    // #write라는 버튼을 누르면
        // #content 에다가 "ㅋㅋㅋ"라고 쓴다.
    // #read라는 버튼을 누르면
        // #content라는 칸에 뭐라고 써있는지 알아내서
        // 그 내용을 alert()함수로 표시한다.
    
    $("#write2").click(function(){
        $("#cont2").val("ㅋㅋㅋ");
    });
    $("#read2").click(function(){
        var contval = $("#cont2").val();
        alert(contval);
    });
    // #write2가 눌리면
        // #cont2에 "ㅋㅋㅋ"라는 내용을 삽입한다.
    // #read2가 눌리면
        // #cont2에 뭐라고 썼는지 알아내서
        // alert으로 표시한다.
    
    
    $("#thumbs img").click(function(){
        var src = $(this).attr("src");
        var alt = $(this).attr("alt");
        var iurl = $(this).attr("data-url");
        $("#stage img").attr("src",src);
        $("#stage p").text(alt);
        $("#stage a").attr("href",iurl);
    });
    // #thumbs안에 있는 img를 눌렀을 때
        // (그중에 눌린 바로 그 img)의 속성중에 src라는 속성의 값을 알아내기   
        // (그중에 눌린 바로 그 img)의 속성중에 alt라는 속성의 값을 알아내기   
        // (그중에 눌린 바로 그 img)의 속성중에 value라는 속성의 값을 알아내기   
        // #stage안에 있는 img의 속성중에 src라는 속성에
            // 아까 알아낸 그 그림 주소를 삽입한다.
        // #stage안에 있는 p의 내용으로 아까 알아낸 그 alt글씨를 삽입한다.
        // #stage안에 있는 a의 속성중에 href라는 속성에
            // 아까 알아낸 url주소를 삽입한다.
    
    
    // Time stamp란?
        // 1970년 1월 1일 00시 00분 00초 부터
        // 바로 지금현재 까지 걸린 시간(ms)
    
    
    
    
    var stat = 0;
    var first;
    
    function chk(){
        var now = new Date();
        now = now.getTime();
        var passed = now - first;
        var min = Math.floor(passed / 60000);
        var sec = Math.floor((passed % 60000) / 1000);
        var msec = Math.floor((passed % 60000) % 1000 / 1000 * 60);
        if(min < 10){ min = "0" + min; }
        if(sec < 10){ sec = "0" + sec; }
        if(msec < 10){ msec = "0" + msec; }
        $("#min").text(min);
        $("#sec").text(sec);
        $("#msec").text(msec);
    }
    var repeat;
    $("#btn").click(function(){
        if(stat == 0){
            stat = 1;
            $("#btn").text("멈춤");
            first = new Date();
            first = first.getTime();
            repeat = setInterval(chk,10);
        }else{
            stat = 0;
            $("#btn").text("시작");
            clearInterval(repeat);
        }
    });
    
    // 변수 stat = 0
    // #btn이 눌렸을때
        // 만약 stat이 0이라면
            // stat = 1
            // #btn에 들어있는 글자를 "멈춤"으로 바꿔준다.
            // timestamp를 찍어둔다 (최초 시간)
            // -*-*-*-*-*-*-*반복할 부분-*-*-*-*-*-*-*-
                // 또 timestamp를 찍어본다. (현재 시간)
                // (현재시간)-(최초시간) => (지나온 시간)(ms)
                    // 예) 162032 => 2분 42초 32ms
                    // 지나온시간을 60000으로 나눈 몫 => 분
                    // 지나온시간 나누기 60000의 나머지 = 42032
                    // 42032를 1000으로 나눈 몫 => 초
                    // 42032를 1000으로 나눈 나머지 = 32 => ms
                // #min에 분숫자를 쓴다.
                // #sec에 초숫자를 쓴다.
                // #msec에 ms초숫자를 쓴다.
            // -*-*-*-*-*-*-*반복할 부분-*-*-*-*-*-*-*-
        // 그게 아니라면
            // stat = 0
            // #btn에 들어있는 글자를 "시작"이라고 바꿔줌.
            // 저 위에서 1초에 60번씩 반복했던 부분을 멈춤.
    
    function tic(){
        var now = new Date();
        var hour = now.getHours();
        var minutes = now.getMinutes();
        var second = now.getSeconds();
        if(hour < 12){
            $("#pm").removeClass("on");
            $("#am").addClass("on");
        }else{
            hour = hour - 12;
            if(hour == 0){hour = 12}
            $("#am").removeClass("on");
            $("#pm").addClass("on");
        }
        
        if(hour < 10){ hour = "0" + hour; }
        if(minutes < 10){ minutes = "0" + minutes; }
        if(second < 10){ second = "0" + second; }
        $("#h").text(hour);
        $("#m").text(minutes);
        $("#s").text(second);
    }
    
    tic();
    setInterval(tic, 1000);
    
    
    
});

































